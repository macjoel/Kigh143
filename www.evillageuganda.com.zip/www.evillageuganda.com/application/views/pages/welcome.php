<body>
    <?php
        if ($this->session->has_userdata('userId')) {

        } else {
    
            ?>
                <script>
                    window.location="login";
                </script>
            <?php    
    
        }
    ?>
    <!--Navbar -->
    <nav class="mb-1 navbar navbar-expand-lg navbar-dark primary-color lighten-1">
        <a class="navbar-brand" href="#">
            eVillage UG
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-555"
            aria-controls="navbarSupportedContent-555" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent-555">
            <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="#">Home
                <span class="sr-only">(current)</span>
                </a>
            </li>

            </ul>
            <ul class="navbar-nav ml-auto nav-flex-icons">
                <!-- Dropdown -->
                <li class="nav-item dropdown notifications-nav">
                    <a class="nav-link dropdown-toggle waves-effect" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                        <span class="badge red" ><span id="notification-counter">0</span></span> <i class="fa fa-bell"></i>
                        <span class="d-none d-md-inline-block">Notifications</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg-right dropdown-info" id="notification-display" style="width: 300px;" aria-labelledby="navbarDropdownMenuLink">
                  
                    </div>
                </li>

                <li class="nav-item avatar dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-55" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    <img src="<?php echo base_url()?>assets/img/evillagelogo.png" style="width: 30px; hieght: 30px;" class="rounded-circle z-depth-0"
                        alt="avatar image">
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg-right dropdown-secondary"
                    aria-labelledby="navbarDropdownMenuLink-55">
                    <a class="dropdown-item" href="<?php echo base_url()?>logout">Log Out</a>
                    </div>
                </li>

            </ul>
        </div>
    </nav>
    <!--/.Navbar -->

    <!-- <div class="containter"> -->

        <div class="row">
            <div class="col-4"></div>
                    <div class="col-4 mt-3">
                        <div class="card card-dark mt-5">
                            <div class="card-body text-center">
                                <h4 class="card-title">LOGGED IN</h4>
                                <hr>
                                <p class="card-text white-text">
                                    <div class="col-12 text-center">
                                        <span class="animated fadeIn infinite"> 
                                            <?php 
                                                //display the data from session
                                                $var = $this->session->userdata;
                                                echo $var['userId'];
                                            ?>
                                        </span> 
                                    </div>
                                    
                                </p>
                            </div>
                        </div>
                    </div>
            <div class="col-4"></div>
        </div>

    

    </div>