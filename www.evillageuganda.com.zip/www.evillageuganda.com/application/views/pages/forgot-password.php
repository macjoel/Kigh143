
    <body class="bg-primary" style="background-image: url('assets/img/bg-xl.jpg'); background-size: cover; background-position: center;">

<!-- Start your project here-->  
<div class="container">
    <div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="text-center">
            <img src="assets/img/evillagelogo.png" class="logo" style="width: 70px; height: 70px;" alt="">
            <br>
            <br>
            <div class="card border-primary">
                <div class="card-header border-primary">
                Reset Password
                </div>
                <div class="card-body">
                    <h5 class="card-title">Forgot your password?</h5>
                    <p class="card-text">Enter your email and we will 
                        <br> 
                        send you instructions on how to reset your password.
                    </p>
                    <div class="md-form md-outline">
                        <input type="email" id="in_rest" class="form-control validate">
                        <label for="in_rest" data-error="wrong" data-success="right">Enter your email</label>
                    </div>
                    <button type="button" id="btnRestPassword" class="btn-sm btn-block btn btn-primary btn-rounded pull-left">Reset Password</button>  

                    <div className="text-mutedtext-right mt-3">
                        <small className="float-left  mb-2">
                            
                            <a href="<?php echo base_url()?>create-account"
                                className="text-decoration-underline tenxt-reset">
                                Create an Account  ?
                            </a>
                            
                        </small>
                        <small className="float-right mb-2 pl-5"> Alread have account
                            <a href="<?php echo base_url()?>" className="text-decoration-underline tenxt-reset">
                                LogIn
                            </a>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End your project here-->
