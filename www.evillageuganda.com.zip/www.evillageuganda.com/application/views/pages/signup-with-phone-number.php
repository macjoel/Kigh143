
    <body class="bg-primary" style="background-image: url('assets/img/bg-xl.jpg'); background-size: cover; background-position: center;">

<!-- Start your project here-->  
<div class="container">
    <div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="text-center">
            <img src="assets/img/evillagelogo.png" class="logo" style="width: 70px; height: 70px;" alt="">
            <br>
            <br>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><b>Signup With Phone Number</b></h5>

                    <div class="md-form md-outline" id="phone_number_field" style="width: 300px;">
                        <input type="text" id="cr_phone_number" class="form-control validate">
                        <label for="cr_phone_number" data-error="wrong" data-success="right">Enter your phone number</label>
                    </div>

                    <div id="recaptcha-container"></div>

                    <div class="md-form md-outline" id="otp_verification_field">
                        <input type="password" id="otp_verification" class="form-control">
                        <label for="otp_verification" data-error="wrong" data-success="right">Enter OTP</label>
                    </div>

                    <button type="button" id="btnSignUpWithPhoneNumber" class="btn-sm btn-block btn btn-primary btn-rounded pull-left mb-3">Sign Up</button>
                    <button type="button" id="btnVerifiyOTP" class="btn-sm btn-block btn btn-success btn-rounded pull-left mb-3">Send OTP</button>    
                    
                    <div className="text-mutedtext-right mt-3">
                        
                        <small className="float-right mb-2 pl-5"> Alread have account
                            <a href="<?php echo base_url()?>" className="ml-10 text-decoration-underline tenxt-reset">
                                LogIn
                            </a>
                        </small>

                    </div>
                    <hr class="hr">
                    
                    <!-- Facebook -->
                    <a class="btn-floating btn-sm btn-rounded text-white" style="background-color: #3b5998;"><i class="fa fa-facebook"> Signup with Facebook</i></a>

                    <a class="btn-floating btn-sm btn-rounded text-white" style="background-color: #dd4b39;"><i class="fa fa-google"> Signup with Google</i></a>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- End your project here-->
