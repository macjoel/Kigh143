
    <body class="bg-primary" style="background-image: url('assets/img/bg-xl.jpg'); background-size: cover; background-position: center;">

<!-- Start your project here-->  
<div class="container">
    <div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="text-center">
            <img src="assets/img/evillagelogo.png" class="logo" style="width: 70px; height: 70px;" alt="">
            <br>
            <br>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-3">Sign Up</h5>
                    <label  class="text-danger" data-success="right"><b id="error_values"></b></label>
                    <div class="md-form md-outline" style="margin-top: -6px;">
                        <input type="email" id="cr_email" class="form-control validate">
                        <label for="cr_email" data-error="wrong" data-success="right">Enter your email</label>
                    </div>
                    

                    <div class="md-form md-outline"  >
                        <input type="password" id="cr_pass" class="form-control validate">
                        <label for="cr_pass" data-error="wrong" data-success="right">Enter your password</label>
                    </div>

                    <button type="button" id="btnSignUp" class="btn-sm btn-block btn btn-primary btn-rounded pull-left mb-3 text-capitalize">Sign Up</button>  
                    
                    <div className="text-mutedtext-right mt-3">
                        
                        <small className="float-right mb-2 pl-5"> Alread have account
                            <a href="<?php echo base_url()?>" className="ml-10 text-decoration-underline tenxt-reset">
                                LogIn
                            </a>
                        </small>

                    </div>
                    <hr class="hr">
                    <div className="text-mutedtext-right md-3">
                        
                        <small className="float-right mb-2 pl-5"> Signup with
                            <a href="<?php echo base_url()?>signup-with-phone-number" className="ml-10 text-decoration-underline tenxt-reset">
                                Phone Number
                            </a>
                        </small>
                        <br>
                        <label for=""><b>OR</b></label>

                    </div>

                    <!-- Facebook -->
                    <button class="btn btn-sm btn-rounded text-white text-capitalize" style="background-color: #3b5998;"><i class="fa fa-facebook"> Signup with Facebook</i></button>
                    <button class="btn btn-sm btn-rounded text-white text-capitalize" style="background-color: #dd4b39;"><i class="fa fa-google"> Signup with Google</i></button>

                </div>
            </div>

        </div>
    </div>
</div>
<!-- End your project here-->
