
    <body class="bg-primary" style="background-image: url('assets/img/bg-xl.jpg'); background-size: cover; background-position: center;">
    <?php
        if ($this->session->has_userdata('userId')) {
            ?>
                <script>
                    window.location="welcome";
                </script>
            <?php 
        }
    ?>
    <!-- Start your project here-->  
    <div class="container">
        <div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
            <div class="text-center">
                <img src="assets/img/evillagelogo.png" class="logo" style="width: 70px; height: 70px;" alt="">
                <br>
                <br>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Sign In</h5>
                        <label  class="text-danger" data-success="right"><b id="error_values"></b></label>
                        <div class="md-form md-outline"  style="margin-top: -6px;">
                            <input type="email" id="lg_email" class="form-control validate">
                            <label for="lg_email" data-error="wrong" data-success="right">Enter your email</label>
                        </div>

                        <div class="md-form md-outline">
                            <input type="password" id="lg_pass" class="form-control validate">
                            <label for="lg_pass" data-error="wrong" data-success="right">Enter your password</label>
                        </div>

                        <button type="button" id="btnEPLogin" class="btn-sm btn-block btn btn-primary btn-rounded pull-left mb-3 text-capitalize mb-3">Sign In</button>  
                        <div className="text-mutedtext-right mt-3">
                            <small className="float-left  mb-2">
                                
                                <a href="<?php echo base_url()?>forgot-password"
                                    className="text-decoration-underline tenxt-reset">
                                    Forgot password?
                                </a>
                                
                            </small>
                            <small className="float-right mb-2">Join the community 
                                <a href="<?php echo base_url()?>create-account" className="text-decoration-underline tenxt-reset">
                                Create account
                                </a>
                            </small>
                        </div>

                        <hr class="hr">
                        <div className="text-mutedtext-right md-3">
                            
                            <small className="float-right mb-2 pl-5"> SignIn with
                                <a href="<?php echo base_url()?>signup-with-phone-number" className="ml-10 text-decoration-underline tenxt-reset">
                                    Phone Number
                                </a>
                            </small>
                            <br>
                            <label for=""><b>OR</b></label>

                        </div>

                        <!-- Facebook -->
                        <button class="btn btn-sm btn-rounded text-white text-capitalize" style="background-color: #3b5998;"><i class="fa fa-facebook"> SignIn with Facebook</i></button>
                        <button class="btn btn-sm btn-rounded text-white text-capitalize" style="background-color: #dd4b39;"><i class="fa fa-google"> SignIn with Google</i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End your project here-->
