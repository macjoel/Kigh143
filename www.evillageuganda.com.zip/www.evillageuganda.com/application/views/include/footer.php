
    <!-- jQuery -->
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="<?php echo base_url()?>assets/js/mdb.min.js"></script>
    <!-- Your custom scripts (optional) -->
    <script type="text/javascript"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-messaging.js"></script>
    <script>
        
        // For Firebase JavaScript SDK v7.20.0 and later, `measurementId` is an optional field
        var firebaseConfig = {
            apiKey: "AIzaSyBHq72cXT8NNZLIZJxvcs3k69ecQKVg9qE",
            authDomain: "evillage-uganda.firebaseapp.com",
            databaseURL: "https://evillage-uganda-default-rtdb.firebaseio.com",
            projectId: "evillage-uganda",
            storageBucket: "evillage-uganda.appspot.com",
            messagingSenderId: "662967377637",
            appId: "1:662967377637:web:221143023561d97295be0c",
            measurementId: "G-70J56YL3DL"
        };

        firebase.initializeApp(firebaseConfig);

        const fcm = firebase.messaging()

        let mToken;

        fcm.getToken({
            vapidKey: 'BJXL5c-VpfyehNa7njNCm7EgpBV5C9ycA3VpfZFau-LM5w1gWH3GP8eT2677EwpJxGXAIrKX7PROrVOdkJcQMxk'
        }).then((token) => {
            // console.log('getToken: ', token);

            mToken = token; 

        });

        

        fcm.onMessage((data) => {
            console.log('onMessage: ', data)

            
            let title = data['data']['title']
            let body = data['data']['body']

            let count = localStorage.getItem("notification-count")
            if(count){
                localStorage.setItem("notification-count", parseInt(count) + 1)
            }else{
                localStorage.setItem("notification-count", 1)
            }

            $("#notification-counter").text(
                localStorage.getItem("notification-count")
            )

            $("#notification-display").append(
                `<a class="dropdown-item" href="#">
                    <i class="fa fa-money mr-2" aria-hidden="true"></i>
                    <span>${title}</span>
                    <span class="float-right"><i class="fa fa-clock-o" aria-hidden="true"></i> ${new 
                        Date().toLocaleString('en-US', {hour: 'numeric', minute: 'numeric', hour12: true})}</span>
                </a>`
            )

        })

        Notification.requestPermission((status) => {
            console.log('requestPermission: ', status)
            if(status == 'granted'){

                new Notification(title, {
                    body: body
                })

            }
        });

        $(document).ready(function(){

            //============SignUp with Email and Password
            $("#btnSignUp").click(function(){

                var cr_email = $("#cr_email").val();
                var cr_pass = $("#cr_pass").val();
                var btnSignUp = document.getElementById("btnSignUp");


                if(cr_email == "" || cr_pass ==""){

                    $("#error_values").removeClass("d-none");
                    $("#error_values").text('Enter all values please...');

                }else{

                    $("#btnSignUp").text("Creating account please wait...").addClass("animated fadeIn infinite disabled");

                    firebase.auth().createUserWithEmailAndPassword(cr_email, cr_pass).then(function(response){
                    firebase.auth().currentUser.sendEmailVerification().then(function() {
                        
                        var user = firebase.auth().currentUser;
                    
                        if (user) {

                            var userToken = user.uid;
                            var userEmail = user.email;
                            var SignUpWithEP = "SignUpWithEP";
                            var tloing = "fbs";


                            $.ajax({
                                url: '<?= base_url('savedata')?>',
                                type: 'POST',
                                data: {
                                    userToken: userToken,
                                    userEmail: userEmail,
                                    tloing:tloing,
                                    SignUpWithEP:SignUpWithEP
                                },
                                success: function (res) {
                                    if(res==1)
                                    {
                                        
                                        $("#cr_email").val("");
                                        $("#cr_pass").val("");

                                        $("#btnSignUp").text("Create Account").removeClass("animated fadeIn infinite disabled");
                                        swal({
                                            title: "Success",
                                            type: "success",
                                            text: "Account created successfully...",
                                        });

                                    }	
                                    else
                                    {
                                        swal({
                                            title: "",
                                            text: "Error try again...",
                                            html: true
                                        });	
                                    }
                                },
                                error: function (res) {
                                    swal({
                                        title: "",
                                        text: "Error try again...",
                                        html: true
                                    });
                                }
                            })
                            

                        } else {

                            swal({
                                title: "",
                                text: "Error try again...",
                                html: true
                            });

                        }
                        
                        // Verification email sent.
                        }).catch(function(error) {

                        });

                    })
                    .catch(function(error){

                        $("#btnSignUp").text("Create Account").removeClass("animated fadeIn infinite disabled");
                        swal({
                            title: "",
                            text: error,
                            html: true
                        });

                    })

                }

            });
            //============End SignUp with Email and Password

            function sendingVerfyEmail(){
                firebase.auth.currentUser.sendEmailVerification().then(function(response){
                    firebase.auth().currentUser.sendEmailVerification(actionCodeSettings).then(function() {
                    // Verification email sent.
                    }).catch(function(error) {
                    });
                })
                .catch(function(error){
                })
            }
            //============End SignUp with Email and Password

            //============End SignIn with Email and Password
            $("#btnEPLogin").click(function(){

                var lg_email = $("#lg_email").val();
                var lg_pass = $("#lg_pass").val();

                if(lg_email == "" || lg_pass ==""){

                    $("#error_values").removeClass("d-none");
                    $("#error_values").text('Enter all values please...');

                }else{

                    $("#error_values").addClass("d-none");
                    $("#btnEPLogin").text("Login please wait...").addClass("animated fadeIn infinite disabled");

                    firebase.auth().signInWithEmailAndPassword(lg_email, lg_pass).then(function(response){
                        
                        var user = firebase.auth().currentUser;

                        if (user) {

                            // User is signed in.
                            var userEmail = user.email;
                            var useruid = user.uid;
                            var checkLogIn = "checkLogIn";
                            
                            // Check if user exists in our database
                            $.ajax({
                                url: '<?= base_url('SignInWithEP')?>',
                                type: 'POST',
                                data: {
                                    userEmail: userEmail,
                                    useruid: useruid,
                                    checkLogIn: checkLogIn

                                },
                                success: function (res) {

                                    if(res==1)
                                    {
                                        
                                        $("#lg_email").val("");
                                        $("#lg_pass").val("");

                                        $("#btnEPLogin").text("Sign In").removeClass("animated fadeIn infinite disabled");

                                        window.location="welcome";

                                    }else{

                                        $("#lg_email").val("");
                                        $("#lg_pass").val("");
                                        $("#btnEPLogin").text("Sign In").removeClass("animated fadeIn infinite disabled");
                                        window.location="welcome";

                                    }
                                    	
                                    
                                },
                                error: function (res) {
                                    swal({
                                        title: "",
                                        text: "Error try again 2...",
                                        html: true
                                    });
                                }
                            })
                            
                        
                        } else {

                        // No user is signed in.
                            swal({
                                title: "Error",
                                type: "error",
                                text: "Logged In error...",
                            });
                        }

                    })
                    .catch(function(error){ 
                        
                        $("#btnEPLogin").text("Sign In").removeClass("animated fadeIn infinite disabled");
                        swal({
                            title: "",
                            text: error,
                            html: true
                        });

                    })

                }

            });
            //============End SignIn with Email and Password

            //============End SignIn with Email and Password
            $("#otp_verification_field").hide();
            $("#btnVerifiyOTP").hide();

            $("#btnSignUpWithPhoneNumber").click(function(){
                var cr_phone_number = $("#cr_phone_number").val();
                // alert(cr_phone_number)
                window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
                'size': 'normal',
                'callback': function(response) {
                    // reCAPTCHA solved, allow signInWithPhoneNumber.
                    // onSignInSubmit();
                }
                });

                var cverify = window.recaptchaVerifier;

                firebase.auth().signInWithPhoneNumber(cr_phone_number, cverify).then(
                    function(response){
                        $("#otp_verification_field").show();
                        $("#btnVerifiyOTP").show();
                        $("#phone_number_field").hide();
                        $("#btnSignUpWithPhoneNumber").hide();
                        console.log(response);
                        window.confirmationResult=response;
                    }).catch(function(error){
                    console.log(error);
                })
            });

            $("#btnVerifiyOTP").click(function(){
                var opt_field = $("#otp_verification").val();

                // alert(opt_field)

                confirmationResult.confirm(opt_field).then((response) => {
                // User signed in successfully.
                const user = response.user;
                // ...
                }).catch((error) => {
                // User couldn't sign in (bad verification code?)
                // ...
                });

            });

            //============
            $("#btnRestPassword").click(function(){

                var in_rest = $("#in_rest").val();

                if(in_rest == ""){
                    swal({
                        title: "",
                        text: "Enter your email...",
                        html: true
                    });
                }else{

                    var auth = firebase.auth();

                    auth.sendPasswordResetEmail(in_rest)
                    .then(function() {  
                    // Email sent.
                        $("#in_rest").val("");
                        swal({
                            title: "",
                            type: "success",
                            text: "Password reset email sent, check your inbox.",
                            html: true
                        });
                        
                    })
                    .catch(function(error) {
                        swal({
                            title: "",
                            text: error,
                            html: true
                        });
                    });

                }
            });

        });

        

    </script>

    </body>
</html>
