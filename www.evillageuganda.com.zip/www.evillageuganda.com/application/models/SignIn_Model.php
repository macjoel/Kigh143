<?php
class SignIn_Model extends CI_Model 
{

    function check_member($userToken,$userEmail)
    {
        // $this->db->where('admin',$userToken);
        // $this->db->where('email', $userEmail);
        // $this->db->where('token', $userToken);
        $query = $this->db->get_where('admin', array('token' => $userToken));
        // $query = $this->db->get('token');
        if ($query->num_rows() > 0){

            $startSession = $this->session->set_userdata('userId', $userEmail);

            if($startSession){

                return 1;
                redirect('welcome', 'refresh');

            }
            redirect('welcome', 'refresh');
            
            // return 1;

        }
        else{
            return 0;
        }
    }

}