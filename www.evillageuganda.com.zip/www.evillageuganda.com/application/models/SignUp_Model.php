<?php
class SignUp_Model extends CI_Model 
{

	public function saveData($data) 
	{
		if($this->db->insert('admin',$data))
		{
		return 1;	
		}
		else
		{
		return 0;	
		}
    }

}