<?php

class AdminModel extends CI_Model {

public function __construct()
    {
        parent::__construct();
    }

    protected $tabled = 'admin';

    protected $allowedFields = [
        'name','email','password','token'
    ];


}