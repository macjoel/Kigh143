<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Pages extends CI_Controller {

	public function __construct()
    {

        parent::__construct();
		$this->load->database();
		/*Load Form Validation Library*/
        $this->load->library('form_validation');
        $this->load->model('AdminModel');
		/*call CodeIgniter's default Constructor*/
		
		$this->load->model('SignUp_Model');
		$this->load->model('SignIn_Model');


    }

	public function view($page = "login")
	{
        if(!file_exists(APPPATH.'views/pages/'.$page.'.php')){
            show_404();
        }
		

		$data['title'] = 'eVillage Uganda | Connecting People Across Uganda | Creating a better Uganda';
		$this->load->view('include/header', $data);
		$this->load->view('pages/'.$page);
		$this->load->view('include/footer');

	}


	public function doLogin(){

		$adminModel = new AdminModel();
		
		// dd($this->request->getVar('gender'))
		$user_vid = $this->input->post('user_vid');
		$user_pass = $this->input->post('user_pass');
		$token = $this->input->post('token');

		$this->db->select('*');
        $this->db->from('admin');
        $this->db->where('email', $user_vid);
        $this->db->where('password', $user_pass);
        $query = $this->db->get();


		if($query) {

			$row = $query->row();
			// if (isset($row))
			// {
			// 	echo $row->id;
			// }

			$this->db->set('token', $token);
			$this->db->where('id', $row->id);
			$this->db->update('admin');

			$res['status'] = '1';
			$res['message'] = 'Login successfull';

		}else{

			$res['status'] = '0';
			$res['message'] = 'Login failed';

		}

		return json_encode($res);

	}

	public function doLoginWithEmailPassword(){

		$user_name = $this->input->post('name');
		$user_email = $this->input->post('email');
		$token = $this->input->post('token');

	}

	public function doSignUp(){
		$SignUp_Model = new SignUp_Model();
		$SignIn_Model = new SignIn_Model();
		
		//Check submit button 
		if($this->input->post('SignUpWithEP')){

			//get form's data and store in local varable
			$userToken = $this->input->post('userToken');
			$userEmail = $this->input->post('userEmail');

			//call saverecords method of SignUp_Model and pass variables as parameter
			$this->SignUp_Model->saverecords($userToken,$userEmail);		
			// echo "Records Saved Successfully";
		}

		if($this->input->post('checkLogIn')){

			$userToken = $this->input->post('useruid');
			$userEmail = $this->input->post('userEmail');

			//call saverecords method of SignIn_Model and pass variables as parameter
			$this->SignIn_Model->check_member($userToken,$userEmail);


		}

	}

	public function savedata(){
		
		$data = array(
					'email' => $this->input->post('userEmail'),
					'token'=>$this->input->post('userToken'),
					'login_type'=>$this->input->post('tloing'),
				);
			
		$this->load->model('SignUp_Model');
		$result=$this->SignUp_Model->saveData($data);
		if($result)
		{
			echo  1;	
		}
		else
		{
			echo  0;	
		}

	}

	public function logout(){
		$this->session->unset_userdata('userId');
		redirect('login', 'refresh');
		
	}

	

}
